
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'patelarpit50',
  applicationName: 'mybackend-todo',
  appUid: 'zTRYLrJ1s46LYStmk9',
  orgUid: '93613b93-9923-4fc4-b9ef-26a6fe0a30a2',
  deploymentUid: 'c55819f5-331c-4f05-9be2-b4c2bfd29e71',
  serviceName: 'mybackend-todo',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'mybackend-todo-dev-listTodos', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.listTodos, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}